// import React, { useState, useEffect } from 'react'

// const Movie = {} => {

// }

// export default Movie