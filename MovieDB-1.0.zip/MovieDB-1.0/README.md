images = 'https://image.tmdb.org/t/p/w500/'
APIKEY = 'api_key=f8773dd7a15349b5bd291aff0bdb3025&page=1'
search = 'https://api.themoviedb.org/3/search/movie?api_key=f8773dd7a15349b5bd291aff0bdb3025&query='
top_rated = 'https://api.themoviedb.org/3/movie/top_rated?api_key=f8773dd7a15349b5bd291aff0bdb3025&language=en-US&page=1'